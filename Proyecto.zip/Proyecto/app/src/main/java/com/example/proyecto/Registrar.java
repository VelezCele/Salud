package com.example.proyecto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Registrar extends AppCompatActivity implements View.OnClickListener {
    Button btncontinuar;
    ImageButton btnregresar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
        btncontinuar=(Button) findViewById(R.id.btnContinuar);
        btnregresar=(ImageButton) findViewById(R.id.btnRegresar);
        btncontinuar.setOnClickListener(this);
        btnregresar.setOnClickListener(this);

    }
    public void regresar(){
        Intent objIntent=new Intent (Registrar.this,MainActivity.class);
        startActivity(objIntent);
        finish();
    }
    public void continuar(){
        Intent objIntent=new Intent (Registrar.this,Inicio.class);
        startActivity(objIntent);
        finish();
    }
    @Override
    public void onClick(View v) {
        if(v==btnregresar){
            regresar();
        }
        if(v==btncontinuar){
            continuar();
        }
    }
}