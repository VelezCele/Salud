package com.example.proyecto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Login extends AppCompatActivity implements View.OnClickListener {
    Button btniniciar;
    ImageButton btnregresar2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btniniciar=(Button) findViewById(R.id.btnIniciar);
        btnregresar2=(ImageButton) findViewById(R.id.btnRegresar2);
        btniniciar.setOnClickListener(this);
        btnregresar2.setOnClickListener(this);

    }
    public void regresar2(){
        Intent objIntent=new Intent (Login.this,MainActivity.class);
        startActivity(objIntent);
        finish();
    }
    public void iniciar(){
        Intent objIntent=new Intent (Login.this,Inicio.class);
        startActivity(objIntent);
        finish();
    }
    @Override
    public void onClick(View v) {
        if(v==btnregresar2){
            regresar2();
        }
        if(v==btniniciar){
            iniciar();
        }
    }
}