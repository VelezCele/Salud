package com.example.proyecto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnregistrar;
    Button btniniciarsesion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnregistrar=(Button) findViewById(R.id.btnRegistrar);
        btniniciarsesion=(Button) findViewById(R.id.btnIniciarSesion);
        btnregistrar.setOnClickListener(this);
        btniniciarsesion.setOnClickListener(this);

    }
    public void registrarse(){
        Intent objIntent=new Intent (MainActivity.this,Registrar.class);
        startActivity(objIntent);
        finish();
    }
    public void login(){
        Intent objIntent=new Intent (MainActivity.this,Login.class);
        startActivity(objIntent);
        finish();
    }
    @Override
    public void onClick(View v) {
        if(v==btnregistrar){
            registrarse();
        }
        if(v==btniniciarsesion){
            login();
        }
    }
}